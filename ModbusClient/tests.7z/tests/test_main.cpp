#include <QtTest/QtTest>
#include <QDebug>

// Test runner that can run specific test categories
int main(int argc, char *argv[]) {
    QCoreApplication app(argc, argv);

    // Check if we want to run only performance tests
    bool runPerformanceOnly = false;
    for (int i = 0; i < argc; ++i) {
        if (QString(argv[i]).contains("performance", Qt::CaseInsensitive)) {
            runPerformanceOnly = true;
            break;
        }
    }

    if (runPerformanceOnly) {
        qDebug() << "Running performance tests only...";
        // Performance tests will be run via QTEST_MAIN in individual files
        return 0;
    }

    qDebug() << "Running all tests...";

    // Regular test execution
    // Tests will be added via QTEST_MAIN in individual test files
    return 0;
}
