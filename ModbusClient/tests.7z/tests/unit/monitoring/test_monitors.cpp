#include <QtTest/QtTest>
#include "monitoring/DiscreteInputMonitor.h"
#include "monitoring/AnalogValueMonitor.h"
#include "monitoring/DataMonitor.h"
#include "core/mapping/DeltaAddressMapper.h"
#include <QLabel>
#include <QLCDNumber>
#include <QProgressBar>

// Reuse MockModbusClient from previous test
#include "test_connection_manager.cpp"

class TestMonitors : public QObject {
    Q_OBJECT

private slots:
    void initTestCase() {
        mockClient = new MockModbusClient(this);
        mapper = new DeltaAddressMapper();
        repository = new DataRepository(this);
    }

    void cleanupTestCase() {
        delete repository;
        delete mapper;
        delete mockClient;
    }

    void testDiscreteInputMonitor() {
        DiscreteInputMonitor* monitor = new DiscreteInputMonitor(mockClient, mapper, this);

        // Create labels
        QVector<QLabel*> labels;
        for (int i = 0; i < 12; ++i) {
            labels.append(new QLabel());
        }
        monitor->setLabels(labels);

        QSignalSpy spy(monitor, &DiscreteInputMonitor::statusChanged);

        // Simulate register read
        emit mockClient->registerReadCompleted(0x0000, 1); // S1 ON

        QCOMPARE(spy.count(), 1);
        QList<QVariant> arguments = spy.first();
        QCOMPARE(arguments.at(0).toInt(), 0); // Input 0
        QCOMPARE(arguments.at(1).toBool(), true); // ON

        // Check label updated
        QCOMPARE(labels[0]->text(), QString("ON"));

        // Cleanup
        qDeleteAll(labels);
        delete monitor;
    }

    void testAnalogValueMonitor() {
        AnalogValueMonitor* monitor = new AnalogValueMonitor(mockClient, mapper, this);

        QLCDNumber* rpmDisplay = new QLCDNumber();
        QProgressBar* powerBar = new QProgressBar();
        monitor->setDisplays(rpmDisplay, powerBar);

        QSignalSpy spy(monitor, &AnalogValueMonitor::valueChanged);

        // Simulate RPM read (address 0x3000)
        emit mockClient->registerReadCompleted(0x3000, 1500);

        QCOMPARE(spy.count(), 1);
        QCOMPARE(rpmDisplay->value(), 1500);

        // Cleanup
        delete powerBar;
        delete rpmDisplay;
        delete monitor;
    }

    void testDataMonitor() {
        DataMonitor* monitor = new DataMonitor(mockClient, repository, this);

        QSignalSpy dataSpy(monitor, &DataMonitor::dataUpdated);
        QSignalSpy logSpy(monitor, &DataMonitor::logMessage);

        // Simulate connection
        mockClient->m_connected = true;

        monitor->startMonitoring();

        QVERIFY(logSpy.count() > 0);

        // Simulate data updates
        emit mockClient->registerReadCompleted(0x3000, 2000); // RPM

        QTest::qWait(100);

        // Check data was added to repository
        QVERIFY(repository->getDataPointCount("RPM_TK") > 0);

        monitor->stopMonitoring();

        delete monitor;
    }

private:
    MockModbusClient* mockClient;
    DeltaAddressMapper* mapper;
    DataRepository* repository;
};

QTEST_MAIN(TestMonitors)
#include "test_monitors.moc"
