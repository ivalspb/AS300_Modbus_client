#include <QtTest/QtTest>
#include "data/DataRepository.h"
#include <QThread>

class TestDataRepository : public QObject {
    Q_OBJECT

private slots:
    void initTestCase() {
        repository = new DataRepository(this);
    }

    void cleanupTestCase() {
        delete repository;
    }

    void cleanup() {
        repository->clearData();
    }

    void testAddDataPoint() {
        QSignalSpy spy(repository, &IDataRepository::dataAdded);

        repository->addDataPoint("RPM_TK", 1500.0);

        QCOMPARE(spy.count(), 1);
        QList<QVariant> arguments = spy.takeFirst();
        QCOMPARE(arguments.at(0).toString(), QString("RPM_TK"));
        QCOMPARE(arguments.at(1).toDouble(), 1500.0);
    }

    void testGetDataPoints() {
        repository->addDataPoint("RPM_TK", 1000.0);
        QThread::msleep(10);
        repository->addDataPoint("RPM_TK", 1500.0);
        QThread::msleep(10);
        repository->addDataPoint("RPM_TK", 2000.0);

        auto points = repository->getDataPoints("RPM_TK");

        QCOMPARE(points.size(), 3);
        QCOMPARE(points[0].value, 1000.0);
        QCOMPARE(points[1].value, 1500.0);
        QCOMPARE(points[2].value, 2000.0);
    }

    void testGetDataPointsWithTimeRange() {
        QDateTime start = QDateTime::currentDateTime();

        repository->addDataPoint("TEMP", 20.0);
        QThread::msleep(100);

        QDateTime middle = QDateTime::currentDateTime();

        repository->addDataPoint("TEMP", 25.0);
        QThread::msleep(100);

        QDateTime end = QDateTime::currentDateTime();

        repository->addDataPoint("TEMP", 30.0);

        // Get all points
        auto allPoints = repository->getDataPoints("TEMP");
        QCOMPARE(allPoints.size(), 3);

        // Get points from middle
        auto laterPoints = repository->getDataPoints("TEMP", middle, end);
        QCOMPARE(laterPoints.size(), 2);
    }

    void testGetAvailableParameters() {
        repository->addDataPoint("RPM_TK", 1000.0);
        repository->addDataPoint("POWER_LEVEL", 50.0);
        repository->addDataPoint("TEMPERATURE", 25.0);

        auto params = repository->getAvailableParameters();

        QCOMPARE(params.size(), 3);
        QVERIFY(params.contains("RPM_TK"));
        QVERIFY(params.contains("POWER_LEVEL"));
        QVERIFY(params.contains("TEMPERATURE"));
    }

    void testClearData() {
        repository->addDataPoint("RPM_TK", 1000.0);
        repository->addDataPoint("POWER_LEVEL", 50.0);

        QCOMPARE(repository->getDataPointCount("RPM_TK"), 1);

        repository->clearData("RPM_TK");

        QCOMPARE(repository->getDataPointCount("RPM_TK"), 0);
        QCOMPARE(repository->getDataPointCount("POWER_LEVEL"), 1);

        repository->clearData(); // Clear all

        QCOMPARE(repository->getDataPointCount("POWER_LEVEL"), 0);
    }

    void testDataPointCount() {
        for (int i = 0; i < 10; ++i) {
            repository->addDataPoint("RPM_TK", i * 100.0);
        }

        QCOMPARE(repository->getDataPointCount("RPM_TK"), 10);
        QCOMPARE(repository->getDataPointCount("UNKNOWN"), 0);
    }

    void testThreadSafety() {
        // Test concurrent read/write operations
        QThreadPool::globalInstance()->setMaxThreadCount(4);

        QSignalSpy spy(repository, &IDataRepository::dataAdded);

        // Multiple threads writing
        QVector<QFuture<void>> futures;
        for (int i = 0; i < 100; ++i) {
            auto future = QtConcurrent::run([this, i]() {
                repository->addDataPoint("TEST", i);
            });
            futures.append(future);
        }

        // Wait for all threads
        for (auto& future : futures) {
            future.waitForFinished();
        }

        QCOMPARE(repository->getDataPointCount("TEST"), 100);
        QCOMPARE(spy.count(), 100);
    }

private:
    DataRepository* repository;
};

QTEST_MAIN(TestDataRepository)
#include "test_data_repository.moc"
