#include <QtTest/QtTest>
#include "core/connection/ConnectionManager.h"
#include "core/interfaces/IModbusClient.h"

// Mock Modbus Client for testing
class MockModbusClient : public IModbusClient {
    Q_OBJECT
public:
    explicit MockModbusClient(QObject* parent = nullptr)
        : IModbusClient(parent)
        , m_connected(false)
        , m_connectCalled(false)
        , m_disconnectCalled(false)
    {}

    bool connectToDevice(const QString& address, quint16 port) override {
        m_connectCalled = true;
        m_lastAddress = address;
        m_lastPort = port;

        // Simulate async connection
        QTimer::singleShot(100, this, [this]() {
            m_connected = true;
            emit connected();
        });

        return true;
    }

    void disconnectFromDevice() override {
        m_disconnectCalled = true;
        m_connected = false;
        emit disconnected();
    }

    bool isConnected() const override {
        return m_connected;
    }

    void readHoldingRegister(quint16 address) override {
        m_lastReadAddress = address;
        // Simulate successful read
        QTimer::singleShot(50, this, [this, address]() {
            emit registerReadCompleted(address, 0x1234);
        });
    }

    void readHoldingRegisters(quint16, quint16) override {}
    void writeHoldingRegister(quint16, quint16) override {}
    void setPollingInterval(int) override {}
    void addPolledRegister(const QString&, quint16) override {}

    // Test helpers
    bool m_connected;
    bool m_connectCalled;
    bool m_disconnectCalled;
    QString m_lastAddress;
    quint16 m_lastPort;
    quint16 m_lastReadAddress;
};

class TestConnectionManager : public QObject {
    Q_OBJECT

private slots:
    void initTestCase() {
        mockClient = new MockModbusClient(this);
        manager = new ConnectionManager(mockClient, this);
    }

    void cleanupTestCase() {
        delete manager;
        delete mockClient;
    }

    void testConnectToDevice() {
        QSignalSpy connectedSpy(manager, &ConnectionManager::connectionStatusChanged);
        QSignalSpy logSpy(manager, &ConnectionManager::logMessage);

        manager->connectToDevice("192.168.0.2", 3200);

        QVERIFY(mockClient->m_connectCalled);
        QCOMPARE(mockClient->m_lastAddress, QString("192.168.0.2"));
        QCOMPARE(mockClient->m_lastPort, static_cast<quint16>(3200));

        // Wait for async connection
        QTest::qWait(200);

        QVERIFY(manager->isConnected());
        QCOMPARE(manager->connectionStatus(), QString("ПОДКЛЮЧЕН"));
        QVERIFY(connectedSpy.count() > 0);
    }

    void testDisconnectFromDevice() {
        // First connect
        manager->connectToDevice("192.168.0.2", 3200);
        QTest::qWait(200);

        QSignalSpy disconnectedSpy(manager, &ConnectionManager::connectionStatusChanged);

        manager->disconnectFromDevice();

        QVERIFY(mockClient->m_disconnectCalled);
        QVERIFY(!manager->isConnected());
        QCOMPARE(manager->connectionStatus(), QString("ОТКЛЮЧЕН"));
        QVERIFY(disconnectedSpy.count() > 0);
    }

    void testConnectionTest() {
        // Connect first
        manager->connectToDevice("192.168.0.2", 3200);
        QTest::qWait(200);

        QSignalSpy testSpy(manager, &ConnectionManager::testResult);

        manager->testConnection();

        // Wait for test to complete
        QTest::qWait(200);

        QVERIFY(testSpy.count() > 0);
        QList<QVariant> arguments = testSpy.first();
        bool success = arguments.at(1).toBool();
        QVERIFY(success);
    }

    void testConnectionTimeout() {
        // Create client that doesn't emit connected signal
        MockModbusClient* slowClient = new MockModbusClient(this);
        ConnectionManager* testManager = new ConnectionManager(slowClient, this);

        QSignalSpy errorSpy(testManager, &ConnectionManager::errorOccurred);

        testManager->connectToDevice("192.168.0.2", 3200);

        // Wait for timeout (10 seconds + margin)
        QTest::qWait(11000);

        QVERIFY(errorSpy.count() > 0);

        delete testManager;
        delete slowClient;
    }

private:
    MockModbusClient* mockClient;
    ConnectionManager* manager;
};

QTEST_MAIN(TestConnectionManager)
#include "test_connection_manager.moc"
