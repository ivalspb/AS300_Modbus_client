#include <QtTest/QtTest>
#include "core/mapping/DeltaAddressMapper.h"
#include "core/mapping/DeltaController.h"

class TestAddressMapper : public QObject {
    Q_OBJECT

private slots:
    void initTestCase() {
        mapper = new DeltaAddressMapper();
    }

    void cleanupTestCase() {
        delete mapper;
    }

    void testDiscreteInputMapping() {
        using namespace DeltaController;

        QCOMPARE(mapper->getDiscreteInputAddress(S1_BUTS), static_cast<quint16>(0x0000));
        QCOMPARE(mapper->getDiscreteInputAddress(S2_PRTS), static_cast<quint16>(0x0001));
        QCOMPARE(mapper->getDiscreteInputAddress(S12_P4_READY), static_cast<quint16>(0x000B));
    }

    void testDiscreteInputNames() {
        using namespace DeltaController;

        QCOMPARE(mapper->getDiscreteInputName(S1_BUTS), QString("S1: Откл БУТС"));
        QCOMPARE(mapper->getDiscreteInputName(S4_AZTS), QString("S4: АЗТС"));
        QCOMPARE(mapper->getDiscreteInputName(S12_P4_READY), QString("S12: ПЧ готов"));
    }

    void testCommandOutputMapping() {
        using namespace DeltaController;

        QCOMPARE(mapper->getCommandOutputAddress(K1_START_TS), static_cast<quint16>(0x1000));
        QCOMPARE(mapper->getCommandOutputAddress(K2_STOP_TS), static_cast<quint16>(0x1001));
        QCOMPARE(mapper->getCommandOutputAddress(K6_AKTIVATION_P4), static_cast<quint16>(0x1005));
    }

    void testAnalogMapping() {
        using namespace DeltaController;

        QCOMPARE(mapper->getAnalogAddress(RPM_TK), static_cast<quint16>(0x3000));
        QCOMPARE(mapper->getAnalogAddress(POWER_LEVEL), static_cast<quint16>(0x3001));
        QCOMPARE(mapper->getAnalogAddress(TEMPERATURE), static_cast<quint16>(0x3002));
        QCOMPARE(mapper->getAnalogAddress(PRESSURE), static_cast<quint16>(0x3003));
    }

    void testAnalogNames() {
        using namespace DeltaController;

        QCOMPARE(mapper->getAnalogName(RPM_TK), QString("Частота вращения ТК"));
        QCOMPARE(mapper->getAnalogName(POWER_LEVEL), QString("Уровень мощности"));
    }

    void testValidAddress() {
        QVERIFY(mapper->isValidAddress(0x0000)); // Discrete input
        QVERIFY(mapper->isValidAddress(0x1000)); // Command output
        QVERIFY(mapper->isValidAddress(0x3000)); // Analog
        QVERIFY(!mapper->isValidAddress(0x5000)); // Invalid
    }

private:
    DeltaAddressMapper* mapper;
};

QTEST_MAIN(TestAddressMapper)
#include "test_address_mapper.moc"
