#include <QtTest/QtTest>
#include "core/modbus/ModbusRequestQueue.h"

class TestRequestQueue : public QObject {
    Q_OBJECT

private slots:
    void initTestCase() {
        // Setup before all tests
    }

    void cleanupTestCase() {
        // Cleanup after all tests
    }

    void init() {
        // Setup before each test
        queue = new ModbusRequestQueue(this);
    }

    void cleanup() {
        // Cleanup after each test
        delete queue;
        queue = nullptr;
    }

    void testEnqueueRead() {
        QVERIFY(queue != nullptr);
        QCOMPARE(queue->size(), 0);

        queue->enqueueRead(0x3000, 1, "TestParam");
        QCOMPARE(queue->size(), 1);
        QVERIFY(queue->hasRequests());
    }

    void testEnqueueWrite() {
        queue->enqueueWrite(0x4100, 0x0001);
        QCOMPARE(queue->size(), 1);

        ModbusRequest request = queue->dequeue();
        QCOMPARE(request.type, RequestType::Write);
        QCOMPARE(request.address, static_cast<quint16>(0x4100));
        QCOMPARE(request.value, static_cast<quint16>(0x0001));
    }

    void testDequeue() {
        queue->enqueueRead(0x3000, 1, "Param1");
        queue->enqueueRead(0x3001, 1, "Param2");

        QCOMPARE(queue->size(), 2);

        ModbusRequest req1 = queue->dequeue();
        QCOMPARE(req1.address, static_cast<quint16>(0x3000));
        QCOMPARE(req1.parameterName, QString("Param1"));

        QCOMPARE(queue->size(), 1);

        ModbusRequest req2 = queue->dequeue();
        QCOMPARE(req2.address, static_cast<quint16>(0x3001));

        QCOMPARE(queue->size(), 0);
        QVERIFY(!queue->hasRequests());
    }

    void testClear() {
        queue->enqueueRead(0x3000, 1);
        queue->enqueueRead(0x3001, 1);
        queue->enqueueWrite(0x4100, 0x0001);

        QCOMPARE(queue->size(), 3);

        queue->clear();

        QCOMPARE(queue->size(), 0);
        QVERIFY(!queue->hasRequests());
    }

    void testThreadSafety() {
        // Test concurrent access
        QSignalSpy spy(queue, &IRequestQueue::requestAdded);

        // Simulate multiple threads adding requests
        for (int i = 0; i < 100; ++i) {
            queue->enqueueRead(0x3000 + i, 1);
        }

        QCOMPARE(queue->size(), 100);
        QCOMPARE(spy.count(), 100);
    }

private:
    ModbusRequestQueue* queue;
};

QTEST_MAIN(TestRequestQueue)
#include "test_request_queue.moc"
