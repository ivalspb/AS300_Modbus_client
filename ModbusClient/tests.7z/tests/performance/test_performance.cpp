#include <QtTest/QtTest>
#include <QtConcurrent/QtConcurrent>
#include "data/DataRepository.h"
#include "core/modbus/ModbusRequestQueue.h"

class TestPerformance : public QObject {
    Q_OBJECT

private slots:
    void initTestCase() {
        qDebug() << "Performance tests starting...";
    }

    void cleanupTestCase() {
        qDebug() << "Performance tests completed";
    }

    void testRepositoryWritePerformance() {
        DataRepository repository;

        QBENCHMARK {
            for (int i = 0; i < 1000; ++i) {
                repository.addDataPoint("TEST_PARAM", i * 1.0);
            }
        }

        // Verify data was actually written
        QCOMPARE(repository.getDataPointCount("TEST_PARAM"), 1000);
    }

    void testRepositoryReadPerformance() {
        DataRepository repository;

        // Add test data first
        for (int i = 0; i < 10000; ++i) {
            repository.addDataPoint("TEST_PARAM", i * 1.0);
        }

        QBENCHMARK {
            auto points = repository.getDataPoints("TEST_PARAM");
            Q_UNUSED(points); // Prevent optimization
        }

        // Verify we got the expected number of points
        auto points = repository.getDataPoints("TEST_PARAM");
        QCOMPARE(points.size(), 10000);
    }

    void testRepositoryReadWithTimeRangePerformance() {
        DataRepository repository;

        // Add test data with timestamps
        QDateTime startTime = QDateTime::currentDateTime();
        for (int i = 0; i < 5000; ++i) {
            repository.addDataPoint("TIME_TEST", i * 1.0);
            QTest::qWait(1); // Small delay to create time spread
        }
        QDateTime endTime = QDateTime::currentDateTime();

        QBENCHMARK {
            auto points = repository.getDataPoints("TIME_TEST", startTime, endTime);
            Q_UNUSED(points);
        }
    }

    void testQueueEnqueueDequeuePerformance() {
        ModbusRequestQueue queue;

        QBENCHMARK {
            // Test enqueue performance
            for (int i = 0; i < 1000; ++i) {
                queue.enqueueRead(0x3000 + i, 1, QString("Param_%1").arg(i));
            }

            // Test dequeue performance
            while (queue.hasRequests()) {
                auto request = queue.dequeue();
                Q_UNUSED(request);
            }
        }

        QVERIFY(!queue.hasRequests());
    }

    void testQueueMixedOperationsPerformance() {
        ModbusRequestQueue queue;

        QBENCHMARK {
            // Mixed read and write operations
            for (int i = 0; i < 500; ++i) {
                if (i % 2 == 0) {
                    queue.enqueueRead(0x3000 + i, 1);
                } else {
                    queue.enqueueWrite(0x4000 + i, i);
                }
            }

            // Process half the queue
            for (int i = 0; i < 250; ++i) {
                if (queue.hasRequests()) {
                    queue.dequeue();
                }
            }

            // Add more operations
            for (int i = 0; i < 200; ++i) {
                queue.enqueueRead(0x5000 + i, 1);
            }

            // Clear remaining
            while (queue.hasRequests()) {
                queue.dequeue();
            }
        }
    }

    void testConcurrentRepositoryWritePerformance() {
        DataRepository repository;

        QBENCHMARK {
            QVector<QFuture<void>> futures;

            // Simulate 10 concurrent writers
            for (int threadId = 0; threadId < 10; ++threadId) {
                auto future = QtConcurrent::run([&repository, threadId]() {
                    for (int i = 0; i < 100; ++i) {
                        repository.addDataPoint(
                            QString("CONCURRENT_TEST_%1").arg(threadId),
                            i + threadId * 1000.0
                        );
                    }
                });
                futures.append(future);
            }

            // Wait for all threads to complete
            for (auto& future : futures) {
                future.waitForFinished();
            }
        }

        // Verify all data was written
        int totalPoints = 0;
        for (int i = 0; i < 10; ++i) {
            totalPoints += repository.getDataPointCount(QString("CONCURRENT_TEST_%1").arg(i));
        }
        QCOMPARE(totalPoints, 1000);
    }

    void testConcurrentRepositoryReadWritePerformance() {
        DataRepository repository;

        // Pre-populate with some data
        for (int i = 0; i < 1000; ++i) {
            repository.addDataPoint("PREPOPULATED", i * 1.0);
        }

        QBENCHMARK {
            QVector<QFuture<void>> futures;

            // 5 readers
            for (int i = 0; i < 5; ++i) {
                auto future = QtConcurrent::run([&repository]() {
                    for (int j = 0; j < 50; ++j) {
                        auto points = repository.getDataPoints("PREPOPULATED");
                        Q_UNUSED(points);
                    }
                });
                futures.append(future);
            }

            // 5 writers
            for (int i = 0; i < 5; ++i) {
                auto future = QtConcurrent::run([&repository, i]() {
                    for (int j = 0; j < 50; ++j) {
                        repository.addDataPoint(
                            QString("CONCURRENT_RW_%1").arg(i),
                            j * 1.0
                        );
                    }
                });
                futures.append(future);
            }

            // Wait for all threads
            for (auto& future : futures) {
                future.waitForFinished();
            }
        }
    }

    void testRepositoryMemoryUsage() {
        DataRepository repository;

        // Test memory usage with large dataset
        const int LARGE_DATASET_SIZE = 100000;

        QTest::qWait(100); // Let system stabilize

        qint64 initialMemory = QTest::qMemoryUsage();

        for (int i = 0; i < LARGE_DATASET_SIZE; ++i) {
            repository.addDataPoint("LARGE_DATASET", i * 1.0);
        }

        qint64 finalMemory = QTest::qMemoryUsage();
        qint64 memoryIncrease = finalMemory - initialMemory;

        qDebug() << "Memory usage for" << LARGE_DATASET_SIZE << "data points:"
                 << memoryIncrease << "bytes";

        // Verify data integrity
        auto points = repository.getDataPoints("LARGE_DATASET");
        QCOMPARE(points.size(), LARGE_DATASET_SIZE);

        // Check a few random points
        QCOMPARE(points[0].value, 0.0);
        QCOMPARE(points[LARGE_DATASET_SIZE / 2].value, (LARGE_DATASET_SIZE / 2) * 1.0);
        QCOMPARE(points[LARGE_DATASET_SIZE - 1].value, (LARGE_DATASET_SIZE - 1) * 1.0);
    }

    void testQueueMemoryUsage() {
        ModbusRequestQueue queue;

        const int LARGE_QUEUE_SIZE = 100000;

        QTest::qWait(100); // Let system stabilize

        qint64 initialMemory = QTest::qMemoryUsage();

        // Fill queue with large number of requests
        for (int i = 0; i < LARGE_QUEUE_SIZE; ++i) {
            queue.enqueueRead(0x3000 + (i % 1000), 1, QString("LargeParam_%1").arg(i));
        }

        qint64 finalMemory = QTest::qMemoryUsage();
        qint64 memoryIncrease = finalMemory - initialMemory;

        qDebug() << "Memory usage for" << LARGE_QUEUE_SIZE << "queue items:"
                 << memoryIncrease << "bytes";

        QCOMPARE(queue.size(), LARGE_QUEUE_SIZE);

        // Clean up
        queue.clear();
    }
};

QTEST_MAIN(TestPerformance)
#include "test_performance.moc"
