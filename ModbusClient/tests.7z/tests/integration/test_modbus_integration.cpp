#include <QtTest/QtTest>
#include "core/modbus/DeltaModbusClient.h"
#include "core/connection/ConnectionManager.h"
#include "monitoring/DataMonitor.h"
#include "data/DataRepository.h"
#include "control/ModeController.h"
#include <QEventLoop>

class TestIntegration : public QObject {
    Q_OBJECT

private slots:
    void initTestCase() {
        // Setup complete system
        client = new DeltaModbusClient(this);
        repository = new DataRepository(this);
        connectionManager = new ConnectionManager(client, this);
        dataMonitor = new DataMonitor(client, repository, this);
        modeController = new ModeController(client, this);
    }

    void cleanupTestCase() {
        if (connectionManager->isConnected()) {
            connectionManager->disconnectFromDevice();
            QTest::qWait(500);
        }
    }

    void testFullConnectionCycle() {
        QSignalSpy connectedSpy(connectionManager, &ConnectionManager::connectionStatusChanged);
        QSignalSpy logSpy(connectionManager, &ConnectionManager::logMessage);

        // Attempt connection
        connectionManager->connectToDevice("192.168.0.2", 3200);

        // Wait for connection attempt
        bool connected = QTest::qWaitFor([this]() {
            return connectionManager->isConnected();
        }, 15000);

        if (connected) {
            QVERIFY(connectionManager->isConnected());
            QCOMPARE(connectionManager->connectionStatus(), QString("ПОДКЛЮЧЕН"));
            QVERIFY(connectedSpy.count() > 0);

            // Test connection
            QSignalSpy testSpy(connectionManager, &ConnectionManager::testResult);
            connectionManager->testConnection();

            QTest::qWait(5000);
            QVERIFY(testSpy.count() > 0);

            // Disconnect
            connectionManager->disconnectFromDevice();
            QTest::qWait(500);

            QVERIFY(!connectionManager->isConnected());
        } else {
            QSKIP("Could not connect to device - device may not be available");
        }
    }

    void testDataMonitoringCycle() {
        // This test requires actual device connection
        if (!connectionManager->isConnected()) {
            QSKIP("Device not connected");
        }

        QSignalSpy dataSpy(dataMonitor, &DataMonitor::dataUpdated);

        dataMonitor->startMonitoring();

        // Wait for some data
        QTest::qWait(5000);

        QVERIFY(dataSpy.count() > 0);

        // Check repository has data
        auto params = repository->getAvailableParameters();
        QVERIFY(params.size() > 0);

        dataMonitor->stopMonitoring();
    }

    void testModeControllerIntegration() {
        if (!connectionManager->isConnected()) {
            QSKIP("Device not connected");
        }

        QSignalSpy modeSpy(modeController, &ModeController::modeChanged);

        // Create combo box and set it
        QComboBox* combo = new QComboBox();
        modeController->setModeComboBox(combo);

        // Select a mode
        combo->setCurrentIndex(0);
        QTest::qWait(100);

        QVERIFY(modeSpy.count() > 0);
        QVERIFY(!modeController->currentMode().isEmpty());

        delete combo;
    }

    void testEndToEndDataFlow() {
        if (!connectionManager->isConnected()) {
            QSKIP("Device not connected");
        }

        // Clear existing data
        repository->clearData();

        // Start monitoring
        dataMonitor->startMonitoring();

        // Wait for data collection
        QTest::qWait(10000);

        // Verify data flow
        auto params = repository->getAvailableParameters();
        QVERIFY(params.size() > 0);

        // Check we have some discrete and analog data
        bool hasDiscreteData = false;
        bool hasAnalogData = false;

        for (const QString& param : params) {
            if (param.startsWith("DiscreteInput")) {
                hasDiscreteData = true;
            }
            if (param == "RPM_TK" || param == "POWER_LEVEL") {
                hasAnalogData = true;
            }
        }

        QVERIFY(hasDiscreteData || hasAnalogData);

        // Stop monitoring
        dataMonitor->stopMonitoring();
    }

private:
    DeltaModbusClient* client;
    DataRepository* repository;
    ConnectionManager* connectionManager;
    DataMonitor* dataMonitor;
    ModeController* modeController;
};

QTEST_MAIN(TestIntegration)
#include "test_integration.moc"
